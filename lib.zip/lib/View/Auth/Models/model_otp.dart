class ModelOTP {
  String emailId;
  String password;

  ModelOTP({required this.emailId, required this.password});
}
