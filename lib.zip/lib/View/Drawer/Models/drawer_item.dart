import '../../../global/enum.dart';

class DrawerItem {
  String title;
  PageType pageType;
  String icon;

  DrawerItem({required this.title,required  this.pageType,required  this.icon});
}