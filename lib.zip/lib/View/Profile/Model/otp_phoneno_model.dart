class ModelPhoneOTP {
  String phoneNumber;
  String otp;

  ModelPhoneOTP({required this.phoneNumber, required this.otp});
}
