// ignore_for_file: non_constant_identifier_names

class Failure {
  bool STATUS;
  String MESSAGE;
  Object DATA;

  Failure({required this.STATUS, required this.MESSAGE, required this.DATA});
}
