class MediaModel {
  String url;
  bool isImage;

  MediaModel({required this.url, required this.isImage});
}
