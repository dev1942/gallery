class Success {
  bool responseStatus;
  String responseMessage;
  Object responseData;
  Success(
      {required this.responseStatus,
      required this.responseMessage,
      required this.responseData});
}
