// ignore_for_file: constant_identifier_names

class AppDimens {
  // margin Start
  static const double bottom_bar_height = dimens_64;
  // margin Start
  static const double margin_xx_large = dimens_19;
  static const double margin_x_large = dimens_17;
  static const double margin_large = dimens_15;
  static const double margin_normal = dimens_13;
  static const double margin_small = dimens_11;
  static const double margin_x_small = dimens_9;
  static const double margin_xx_small = dimens_7;
  static const double margin_xxx_small = dimens_5;
  static const double margin_xxxx_small = dimens_3;

  // margin End

  // Size Start
  static const double dimens_1 = 1.0;
  static const double dimens_2 = 2.0;
  static const double dimens_3 = 3.0;
  static const double dimens_4 = 4.0;
  static const double dimens_5 = 5.0;
  static const double dimens_6 = 6.0;
  static const double dimens_7 = 7.0;
  static const double dimens_8 = 8.0;
  static const double dimens_9 = 9.0;
  static const double dimens_10 = 10.0;
  static const double dimens_11 = 11.0;
  static const double dimens_12 = 12.0;
  static const double dimens_13 = 13.0;
  static const double dimens_14 = 14.0;
  static const double dimens_15 = 15.0;
  static const double dimens_16 = 16.0;
  static const double dimens_18 = 18.0;
  static const double dimens_17 = 17.0;
  static const double dimens_19 = 19.0;
  static const double dimens_20 = 20.0;
  static const double dimens_21 = 21.0;
  static const double dimens_22 = 22.0;
  static const double dimens_23 = 23.0;
  static const double dimens_24 = 24.0;
  static const double dimens_25 = 25.0;
  static const double dimens_26 = 26.0;
  static const double dimens_27 = 27.0;
  static const double dimens_28 = 28.0;
  static const double dimens_29 = 29.0;
  static const double dimens_30 = 30.0;
  static const double dimens_32 = 32.0;
  static const double dimens_33 = 33.0;
  static const double dimens_34 = 34.0;
  static const double dimens_35 = 35.0;
  static const double dimens_36 = 36.0;
  static const double dimens_38 = 38.0;
  static const double dimens_37 = 37.0;
  static const double dimens_40 = 40.0;
  static const double dimens_42 = 42.0;
  static const double dimens_44 = 44.0;
  static const double dimens_46 = 46.0;
  static const double dimens_48 = 48.0;
  static const double dimens_50 = 50.0;
  static const double dimens_51 = 51.0;
  static const double dimens_54 = 54.0;
  static const double dimens_56 = 56.0;
  static const double dimens_60 = 60.0;
  static const double dimens_62 = 62.0;
  static const double dimens_64 = 64.0;
  static const double dimens_66 = 66.0;
  static const double dimens_69 = 69.0;
  static const double dimens_70 = 70.0;
  static const double dimens_72 = 72.0;
  static const double dimens_74 = 74.0;
  static const double dimens_80 = 80.0;
  static const double dimens_85 = 85.0;
  static const double dimens_90 = 90.0;
  static const double dimens_100 = 100.0;
  static const double dimens_105 = 105.0;
  static const double dimens_110 = 110.0;
  static const double dimens_120 = 120.0;
  static const double dimens_125 = 125.0;
  static const double dimens_130 = 130.0;
  static const double dimens_140 = 140.0;
  static const double dimens_142 = 142.0;
  static const double dimens_145 = 145.0;
  static const double dimens_150 = 150.0;
  static const double dimens_160 = 160.0;
  static const double dimens_170 = 170.0;
  static const double dimens_177 = 177.0;
  static const double dimens_190 = 190.0;
  static const double dimens_200 = 200.0;
  static const double dimens_210 = 210.0;
  static const double dimens_220 = 220.0;
  static const double dimens_230 = 230.0;
  static const double dimens_280 = 280.0;
  static const double dimens_300 = 300.0;
  static const double dimens_360 = 360.0;

// Size End
}
