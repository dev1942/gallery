import 'credit_card_widget.dart';

class CreditCardBrand {
  CardType? brandName;

  CreditCardBrand(this.brandName);
}
