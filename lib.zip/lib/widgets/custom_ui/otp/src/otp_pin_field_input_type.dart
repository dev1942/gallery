enum OtpPinFieldInputType { none, password, custom }

enum OtpPinFieldDecoration {
  defaultPinBoxDecoration,
  underlinedPinBoxDecoration,
  roundedPinBoxDecoration,
  custom
}
